from django.apps import AppConfig


class GeConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "ge"
