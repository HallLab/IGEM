# from .models import Choice, Question


def FilterView(request, database_id):
    ...
