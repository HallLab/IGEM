# flake8: noqa
from .get import get_data
from .load import load_data, statistic
