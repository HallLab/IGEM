# from igem.omics import db
# from pathlib import Path

# import pytest


def test_ncbi_create_table():
    # y = db.create_table()
    # print(y)
    assert 2 == 2
