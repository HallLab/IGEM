# from django.urls import path

# from . import views

# app_name = "ge"


# urlpatterns = [
#     # # CONNECTOR VIEWS
#     # path("connector/", views.listview_connector, name="listview_connector"),
#     # path(
#     #     "connector/<int:id>/edit/", views.ConnectorView.as_view(), name="edit_connector"
#     # ),
#     # # WORDTERM VIEWS
#     # path("wordterm/", views.listview_wordterm, name="listview_wordterm"),
#     # path("wordterm/<int:id>/edit/", views.WordTermView.as_view(), name="edit_wordterm"),
# ]
