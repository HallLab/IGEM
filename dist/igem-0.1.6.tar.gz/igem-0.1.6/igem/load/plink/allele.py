from enum import Enum

__all__ = ["Allele"]


class Allele(Enum):
    a0 = 0
    a1 = 1
